const Selector = {
  CUSTOMFILE: '.custom-file input[type="file"]',
  CUSTOMFILELABEL: '.custom-file-label',
  FORM: 'form',
  INPUT: 'input',
}

export default Selector
